package Assign32starter;

public class Riddle {
    String riddle;

    String answer;

    public Riddle(String riddle, String answer){
        this.riddle = riddle;
        this.answer = answer;
    }

    public String getRiddle() {
        return riddle;
    }

    public String getAnswer() {
        return answer;
    }
}
